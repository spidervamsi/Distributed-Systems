package edu.buffalo.cse.cse486586.groupmessenger2;

public class Packet {
    String msg;
    float msgNo;
    float maxMsgNo;

}
